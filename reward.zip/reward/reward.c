#include<stdio.h>
#define REWARD 10
int main(){
    double f,i,dist;
    int reward;
    printf("Enter the final Kms:");
    scanf("%lf",&f);
    printf("Enter the initial Kms:");
    scanf("%lf",&i);
    dist=f-i;
    reward= dist*REWARD;
    printf("Your reward is %d",reward);  
    return 0;
}
