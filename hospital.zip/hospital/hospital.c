#include<stdio.h>
int main(){
    double vol,rate,t;
    printf("Enter the volume of medication to be infussed in ml:");
    scanf("%lf",&vol);
    printf("Enter the time in  minutes taken to infuse the medicine:");
    scanf("%lf",&t);
    rate=vol/(t/60);
    printf("The quanity of medcation to be infused is: %f mm/hr \n",vol);
    printf("The rate at which the pump should be set is: %f ml/hr",rate);
    return 0;
} 
