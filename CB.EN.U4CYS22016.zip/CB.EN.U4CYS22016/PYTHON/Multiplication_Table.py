<?xml version="1.0"?>
<flowgorithm fileversion="3.0">
    <attributes>
        <attribute name="name" value=""/>
        <attribute name="authors" value="CB.EN.U4CYS22016"/>
        <attribute name="about" value=""/>
        <attribute name="saved" value="2022-11-04 10:52:21 AM"/>
        <attribute name="created" value="Q0IuRU4uVTRDWVMyMjAxNjsyMDIyMjNNQVlDMDA1MzsyMDIyLTExLTA0OzA5OjMzOjAwIEFNOzMwNTI="/>
        <attribute name="edited" value="Q0IuRU4uVTRDWVMyMjAxNjsyMDIyMjNNQVlDMDA1MzsyMDIyLTExLTA0OzEwOjUyOjIxIEFNOzM7MzE1OA=="/>
    </attributes>
    <function name="Main" type="None" variable="">
        <parameters/>
        <body>
            <declare name="a" type="Integer" array="False" size=""/>
            <comment text="Declare the variables a,b,c which represents coefficients "/>
            <output expression="&quot;Input value for coefficient a:&quot;" newline="True"/>
            <comment text="input values to form the quadratic Equation"/>
            <input variable="a"/>
            <declare name="b" type="Integer" array="False" size=""/>
            <output expression="&quot;Input value for coefficient b:&quot;" newline="True"/>
            <input variable="b"/>
            <declare name="c" type="Integer" array="False" size=""/>
            <output expression="&quot;Input value for coefficient c:&quot;" newline="True"/>
            <input variable="c"/>
            <comment text="Declare the variable x"/>
            <declare name="x" type="Real" array="False" size=""/>
            <comment text="Declare two variables r1 and r2 to store the values of roots"/>
            <declare name="r1" type="Real" array="False" size=""/>
            <comment text="Equation to find the first root"/>
            <assign variable="r1" expression="(-b+(b^2-4*a*c)^0.5)/(2*a)"/>
            <declare name="r2" type="Real" array="False" size=""/>
            <comment text="Equation to find the second root&#13;&#10;"/>
            <assign variable="r2" expression="(-b-(b^2-4*a*c)^0.5)/(2*a)"/>
            <comment text="output statements for the roots"/>
            <output expression="&quot;The first root of the given Equation is:&quot;&amp;r1" newline="True"/>
            <output expression="&quot;The second root of the given equation is:&quot; &amp;r2" newline="True"/>
        </body>
    </function>
</flowgorithm>

