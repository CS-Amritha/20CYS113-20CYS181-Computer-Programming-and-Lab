fact = 1
print("enter the no")
n = int(input())
if n < 0:
    print("no fact for negative nos")
else:
    if n == 0:
        print("factorial is 1")
    else:
        for i in range(1, n + 1, 1):
            fact = fact * i
        print("the factorial of" + str(n) + "is" + str(fact))
