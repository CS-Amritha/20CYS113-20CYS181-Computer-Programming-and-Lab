# to print the fibonocci series
print("Enter the number you want:")

# to input the value count from user
count = int(input())

# initially num and num1 is one
num = 1
num1 = 1
print(num)

# while loop used to check if count is less than one
while count > 1:
    print(num1)
    num1 = num + num1
    num = num1 - num
    count = count - 1
