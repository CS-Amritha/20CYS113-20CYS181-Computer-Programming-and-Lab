/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main() {
    int a, b, r;
    float c;

    printf("Enter the Divisor: ");
    scanf("%d", &a);

    printf("Enter the Dividend: ");
    scanf("%d", &b);

    c = (float)a / b;
    r = a - b * (int)c;

    printf("Reminder of the given division is: %d\n", r);

    return 0;
}

