#include<stdio.h>
int main(){
   int t;
   double T;
   printf("Enter the time in hours since power failure:");
   scanf("%d",&t);
   T= (4*t*t)/(t+2)-20;
   printf("The Temperature inside the freezer is: %f",T);
   return 0;
}
